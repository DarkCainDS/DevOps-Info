# intro-devops

Este proyecto tiene todo lo visto en el curso de introducción a devops

la carpeta "codigos" tiene todos los archivos terraforms para crear el primer pipeline que te ayudara a montar la infra, con el cual podrás usar la carpeta repositorio-de-cicd para crear tus siguientes pipeline

la carpeta reposiorio-de-cicd tiene todo lo necesario para crear los pipelines de frontend, serverless, base de datos y de backend ci tal cual se ve en el curso

la carpeta repositorio-de-aplicaciones tiene los repositorios de aplicación para los pipelines creados en en la práctica del curso

Puedes tomar cada uno de esas carpetas y crear un repo en alguna plataforma de git (github,bitbucket,gitlab,etc) y apuntar tus pipelines a ese repo para poder terminar la práctica o simplemente puedes apuntar el pipeline a otro repo sin ningún problema, los archivos están para que te guíes.




